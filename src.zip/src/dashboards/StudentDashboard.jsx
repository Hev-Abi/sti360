import { useState } from "react";
import DashboardShell from "../components/DashboardShell";
import { logoutUser } from "../lib/auth";

export default function StudentDashboard({ onLogout }) {
  const [nav, setNav] = useState("home");

  const handleLogout = async () => {
    await logoutUser();
    navigate("/login"); 
  };

  return (
    <DashboardShell
      role="S"
      nav={[{ key: "home", label: "Student Dashboard" }]}
      activeNav={nav}
      setActiveNav={setNav}
      onLogout={handleLogout}
    >
      <h1>Student Dashboard</h1>
    </DashboardShell>
  );
}