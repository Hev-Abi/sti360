import { useState } from "react";
import { useNavigate } from "react-router-dom";
import DashboardShell from "../components/DashboardShell";
import { logoutUser } from "../lib/auth";

import TrackPrograms from "../features/marketing/TrackPrograms";
import LeadsTracking from "../features/marketing/LeadsTracking";
import MarketingAnalytics from "../features/marketing/MarketingAnalytics";
import MarketingReportGenerator from "../features/marketing/MarketingReportGenerator";

export default function MarketingDashboard() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState("programs");

  const handleLogout = async () => {
    await logoutUser();
    navigate("/login");
  };

  const navItems = [
    { key: "programs", label: "Programs", component: <TrackPrograms /> },
    { key: "leads", label: "Leads", component: <LeadsTracking /> },
    { key: "analytics", label: "Analytics", component: <MarketingAnalytics /> },
    { key: "reports", label: "Reports", component: <MarketingReportGenerator /> }
  ];

  const activeComponent =
    navItems.find(item => item.key === activeNav)?.component;

  return (
    <DashboardShell
      role="SAO"
      nav={navItems.map(({ key, label }) => ({ key, label }))}
      activeNav={activeNav}
      setActiveNav={setActiveNav}
      onLogout={handleLogout}
    >
      {activeComponent}
    </DashboardShell>
  );
}