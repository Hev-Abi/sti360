export default function FeederLeads() {
  const feederData = [
    { school: "ABC High School", leads: 120, enrolled: 45 },
    { school: "XYZ Academy", leads: 80, enrolled: 30 },
  ];

  return (
    <div>
      <h3>Feeder School Leads</h3>

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>School</th>
            <th>Total Leads</th>
            <th>Enrolled</th>
          </tr>
        </thead>
        <tbody>
          {feederData.map((item, i) => (
            <tr key={i}>
              <td>{item.school}</td>
              <td>{item.leads}</td>
              <td>{item.enrolled}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}