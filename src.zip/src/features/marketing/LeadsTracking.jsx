import { useState } from "react";
import FeederLeads from "./FeederLeads";
import NonFeederLeads from "./NonFeederLeads";

export default function LeadsTracking() {
  const [tab, setTab] = useState("feeder");

  return (
    <div>
      <h2>Leads Tracking</h2>

      <div style={{ marginBottom: "20px" }}>
        <button onClick={() => setTab("feeder")}>
          Feeder Schools
        </button>

        <button onClick={() => setTab("nonfeeder")}>
          Non-Feeder Leads
        </button>
      </div>

      {tab === "feeder" && <FeederLeads />}
      {tab === "nonfeeder" && <NonFeederLeads />}
    </div>
  );
}