import jsPDF from "jspdf";

export default function MarketingReportGenerator() {
  // SAMPLE DATA (later from database)
  const reportData = {
    totalLeads: 500,
    enrolled: 180,
    conversionRate: "36%",
    topFeeder: "ABC High School",
    bestSource: "Facebook Ads",
  };

  const generatePDF = () => {
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text("Marketing Report", 20, 20);

    doc.setFontSize(12);
    doc.text(`Total Leads: ${reportData.totalLeads}`, 20, 40);
    doc.text(`Total Enrolled: ${reportData.enrolled}`, 20, 50);
    doc.text(`Conversion Rate: ${reportData.conversionRate}`, 20, 60);
    doc.text(`Top Feeder School: ${reportData.topFeeder}`, 20, 70);
    doc.text(`Best Marketing Source: ${reportData.bestSource}`, 20, 80);

    doc.save("Marketing_Report.pdf");
  };

  return (
    <div>
      <h2>Marketing Report Generator</h2>

      <div style={{ marginTop: "20px" }}>
        <p><strong>Total Leads:</strong> {reportData.totalLeads}</p>
        <p><strong>Total Enrolled:</strong> {reportData.enrolled}</p>
        <p><strong>Conversion Rate:</strong> {reportData.conversionRate}</p>
        <p><strong>Top Feeder School:</strong> {reportData.topFeeder}</p>
        <p><strong>Best Source:</strong> {reportData.bestSource}</p>
      </div>

      <button
        onClick={generatePDF}
        style={{
          marginTop: "20px",
          padding: "10px 20px",
          background: "#4CAF50",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Export to PDF
      </button>
    </div>
  );
}