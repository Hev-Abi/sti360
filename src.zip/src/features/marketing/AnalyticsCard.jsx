export default function AnalyticsCard({ title, value }) {
  return (
    <div
      style={{
        padding: "20px",
        borderRadius: "10px",
        background: "#f4f6f8",
        boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
        minWidth: "200px",
      }}
    >
      <h4 style={{ marginBottom: "10px" }}>{title}</h4>
      <h2>{value}</h2>
    </div>
  );
}