export default function NonFeederLeads() {
  const data = [
    { source: "Facebook Ads", leads: 200 },
    { source: "Website", leads: 150 },
    { source: "Walk-in", leads: 60 },
  ];

  return (
    <div>
      <h3>Non-Feeder Leads</h3>

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Source</th>
            <th>Total Leads</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, i) => (
            <tr key={i}>
              <td>{item.source}</td>
              <td>{item.leads}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}