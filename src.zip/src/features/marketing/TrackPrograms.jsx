export default function TrackPrograms() {
  return (
    <div>
      <h2>Programs Offered</h2>
      <p>This is where you will track marketing programs.</p>
    </div>
  );
}   