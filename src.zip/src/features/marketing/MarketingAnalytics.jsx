import AnalyticsCard from "./AnalyticsCard";

export default function MarketingAnalytics() {
  const totalLeads = 500;
  const totalEnrolled = 180;

  const conversionRate = ((totalEnrolled / totalLeads) * 100).toFixed(1) + "%";

  const topFeeder = "ABC High School";
  const bestSource = "Facebook Ads";

  return (
    <div>
      <h2>Marketing Analytics</h2>

      <div
        style={{
          display: "flex",
          gap: "20px",
          flexWrap: "wrap",
          marginTop: "20px",
        }}
      >
        <AnalyticsCard title="Total Leads" value={totalLeads} />
        <AnalyticsCard title="Total Enrolled" value={totalEnrolled} />
        <AnalyticsCard title="Conversion Rate" value={conversionRate} />
        <AnalyticsCard title="Top Feeder School" value={topFeeder} />
        <AnalyticsCard title="Best Marketing Source" value={bestSource} />
      </div>
    </div>
  );
}