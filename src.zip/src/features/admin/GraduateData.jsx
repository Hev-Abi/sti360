export default function GraduateData() {
  return <h2>Graduate Data Analytics</h2>;
}